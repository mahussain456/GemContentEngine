# GEM Content Engine Branding Package

Domain: thegeminfo.com

This package contains production-ready brand assets based on the selected premium direction.

## Recommended files to use first

- Website header logo: `logos/svg/GEM_primary_horizontal.svg`
- Website header PNG fallback: `logos/png/GEM_primary_horizontal_2000w.png`
- Favicon: `web-assets/favicon.ico`
- Apple touch icon: `web-assets/apple-touch-icon.png`
- Social profile avatar: `social/GEM_social_avatar_1080.png`
- Open Graph preview image: `social/GEM_open_graph_1200x630.jpg`
- CSS tokens: `web-assets/gem-brand-tokens.css`
- Brand guide PDF: `brand-guide/GEM_brand_guide.pdf`

## Color Palette

- Deep Forest: #0E2A1F
- Pine Green: #1B4D3E
- Sage: #A7BFAE
- Mist: #E9F1EC
- Warm Beige: #F4EFE6
- Stone: #D8D2C7
- Clay: #DAD4C6
- Charcoal: #1A1A1A
- Gold Accent: #C8A96A

## Font Direction

Use Playfair Display or EB Garamond for headlines.
Use Inter for UI, navigation, buttons, body copy, and dashboard elements.

Font files are not included. Use Google Fonts or your website font provider.
